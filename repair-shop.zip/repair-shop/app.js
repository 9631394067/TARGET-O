// ================================================
//  RepairPro - Smart Repair Shop Manager
//  app.js - Complete Rewrite (v2)
// ================================================

// ============ DATA STORE ============
let db = {
  orders: [],
  parts: [],
  technicians: [],
  settings: { shopName: 'My Repair Shop', ownerName: 'Admin', phone: '', gst: '', address: '' }
};
let orderCounter = 1000;

// ============ INIT ============
document.addEventListener('DOMContentLoaded', async () => {
  await loadDB();
  initNavigation();
  initForms();
  initSearch();
  setDate();
  renderDashboard();
  loadSettings();
  updatePendingBadge();

  // Close modals on overlay click
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) closeModal(overlay.id);
    });
  });
});

// ============ DATA PERSISTENCE ============
// Primary storage: local server database file (data/repairpro-data.json)
// Secondary storage: IndexedDB + LocalStorage fallback for offline/browser recovery.
const API_BASE = '';
const DB_NAME = 'RepairProPermanentDB';
const DB_VERSION = 1;
const DB_STORE = 'appData';

async function serverGetDB() {
  const res = await fetch(`${API_BASE}/api/data`, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Server read failed: ${res.status}`);
  return await res.json();
}

async function serverSaveDB() {
  const res = await fetch(`${API_BASE}/api/data`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ db, orderCounter })
  });
  if (!res.ok) throw new Error(`Server save failed: ${res.status}`);
  return await res.json();
}

function openRepairDB() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB not supported'));
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const idb = req.result;
      if (!idb.objectStoreNames.contains(DB_STORE)) idb.createObjectStore(DB_STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('IndexedDB open failed'));
  });
}

async function writeIndexedDB() {
  const idb = await openRepairDB();
  return new Promise((resolve, reject) => {
    const tx = idb.transaction(DB_STORE, 'readwrite');
    tx.objectStore(DB_STORE).put({ db, orderCounter, savedAt: new Date().toISOString() }, 'current');
    tx.oncomplete = () => { idb.close(); resolve(); };
    tx.onerror = () => { idb.close(); reject(tx.error); };
  });
}

async function readIndexedDB() {
  const idb = await openRepairDB();
  return new Promise((resolve, reject) => {
    const tx = idb.transaction(DB_STORE, 'readonly');
    const req = tx.objectStore(DB_STORE).get('current');
    req.onsuccess = () => { const value = req.result || null; idb.close(); resolve(value); };
    req.onerror = () => { idb.close(); reject(req.error); };
  });
}

async function requestPersistentStorage() {
  try {
    if (navigator.storage && navigator.storage.persist) await navigator.storage.persist();
  } catch (e) { console.warn('Persistent storage request unavailable:', e); }
}

async function saveDB() {
  // Save to the actual project data file first. Browser stores are recovery copies.
  try {
    await serverSaveDB();
  } catch (e) {
    console.warn('Server save unavailable; keeping browser backup:', e);
  }
  try {
    const serialized = JSON.stringify(db);
    localStorage.setItem('repairpro_db', serialized);
    localStorage.setItem('repairpro_counter', orderCounter.toString());
    await writeIndexedDB();
  } catch(e) {
    console.error('Browser backup save error:', e);
  }
}

async function loadDB() {
  await requestPersistentStorage();

  // 1) Real project database file via local server.
  try {
    const serverSaved = await serverGetDB();
    if (serverSaved && serverSaved.db) {
      db = serverSaved.db;
      orderCounter = parseInt(serverSaved.orderCounter) || orderCounter;
      // Keep browser recovery copies synchronized.
      localStorage.setItem('repairpro_db', JSON.stringify(db));
      localStorage.setItem('repairpro_counter', orderCounter.toString());
      try { await writeIndexedDB(); } catch (_) {}
      return;
    }
  } catch (e) {
    console.warn('Server database unavailable; checking browser backup:', e);
  }

  // 2) Existing IndexedDB data (migrates it to the server on first successful save).
  try {
    const idbSaved = await readIndexedDB();
    if (idbSaved && idbSaved.db) {
      db = idbSaved.db;
      orderCounter = parseInt(idbSaved.orderCounter) || orderCounter;
      await saveDB();
      return;
    }
  } catch (e) { console.warn('IndexedDB unavailable:', e); }

  // 3) Existing LocalStorage data.
  try {
    const saved = localStorage.getItem('repairpro_db');
    const counter = localStorage.getItem('repairpro_counter');
    if (saved) {
      db = JSON.parse(saved);
      if (counter) orderCounter = parseInt(counter) || orderCounter;
      await saveDB();
      return;
    }
  } catch (e) { console.warn('LocalStorage migration failed:', e); }

  // 4) First run: create demo data and persist it to the real database file.
  loadDemoData();
  await saveDB();
}

function exportBackup() {
  const payload = {
    app: 'RepairPro',
    version: 2,
    type: 'full-backup',
    exportedAt: new Date().toISOString(),
    orderCounter,
    db
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `RepairPro-Backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  showToast('Backup file download ho gayi!', 'success');
}

function mergeUniqueById(currentItems, backupItems) {
  const result = Array.isArray(currentItems) ? [...currentItems] : [];
  const existingIds = new Set(result.map(item => item && item.id).filter(Boolean));

  (Array.isArray(backupItems) ? backupItems : []).forEach(item => {
    if (!item) return;
    if (item.id && existingIds.has(item.id)) return; // Keep current data
    result.push(item);
    if (item.id) existingIds.add(item.id);
  });

  return result;
}

function mergeRepairProData(currentDb, backupDb) {
  const current = currentDb || {};
  const backup = backupDb || {};

  return {
    ...current,
    // Current data is always preserved. Backup only adds records that are not already present.
    orders: mergeUniqueById(current.orders, backup.orders),
    parts: mergeUniqueById(current.parts, backup.parts),
    technicians: mergeUniqueById(current.technicians, backup.technicians),
    // Keep current shop settings; do not unexpectedly overwrite them during restore.
    settings: (current.settings && typeof current.settings === 'object')
      ? { ...current.settings }
      : (backup.settings && typeof backup.settings === 'object' ? { ...backup.settings } : {})
  };
}

function importBackup(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const raw = JSON.parse(reader.result);

      // Accept:
      // 1) Download Backup files
      // 2) data/repairpro-data.json
      // 3) data/repairpro-data.backup.json
      const payload = raw && raw.app === 'RepairPro' && raw.db
        ? raw
        : (raw && raw.db ? {
            app: 'RepairPro',
            version: 2,
            orderCounter: raw.orderCounter,
            db: raw.db
          } : null);

      const valid =
        payload &&
        payload.db &&
        Array.isArray(payload.db.orders) &&
        Array.isArray(payload.db.parts) &&
        Array.isArray(payload.db.technicians) &&
        payload.db.settings &&
        typeof payload.db.settings === 'object';

      if (!valid) {
        throw new Error('This is not a valid RepairPro data/backup file.');
      }

      const currentCounts = {
        orders: Array.isArray(db.orders) ? db.orders.length : 0,
        parts: Array.isArray(db.parts) ? db.parts.length : 0,
        technicians: Array.isArray(db.technicians) ? db.technicians.length : 0
      };

      const merged = mergeRepairProData(db, payload.db);
      const added = {
        orders: merged.orders.length - currentCounts.orders,
        parts: merged.parts.length - currentCounts.parts,
        technicians: merged.technicians.length - currentCounts.technicians
      };

      const message =
        `Backup merge karne par current data delete nahi hoga.\\n\\n` +
        `Current Orders: ${currentCounts.orders}\\n` +
        `Backup se naye Orders: ${added.orders}\\n` +
        `Backup se naye Parts: ${added.parts}\\n` +
        `Backup se naye Technicians: ${added.technicians}\\n\\n` +
        `Current data + backup ke naye records merge honge. Continue?`;

      if (!confirm(message)) return;

      db = merged;
      const backupCounter = parseInt(payload.orderCounter, 10) || 1000;
      orderCounter = Math.max(parseInt(orderCounter, 10) || 1000, backupCounter);

      // Save the merged result to the permanent project files and browser recovery copies.
      await saveDB();

      alert(
        `Backup successfully merge ho gaya.\\n\\n` +
        `Naye Orders: ${added.orders}\\n` +
        `Naye Parts: ${added.parts}\\n` +
        `Naye Technicians: ${added.technicians}\\n\\n` +
        `Current data safe hai. App reload hoga.`
      );
      location.reload();
    } catch (e) {
      console.error('RepairPro restore/merge error:', e);
      alert('Backup/Data file valid nahi hai. RepairPro ka JSON backup ya data folder ki repairpro-data.json file select karein.');
    } finally {
      event.target.value = '';
    }
  };

  reader.onerror = () => {
    alert('Backup file read nahi ho paayi.');
    event.target.value = '';
  };

  reader.readAsText(file);
}

function loadDemoData() {
  db.technicians = [
    { id: 't1', name: 'Rahul Sharma', phone: '9876543210', spec: 'Samsung Specialist', status: 'Active' },
    { id: 't2', name: 'Amit Kumar', phone: '9876543211', spec: 'iPhone Specialist', status: 'Active' },
    { id: 't3', name: 'Suresh Verma', phone: '9876543212', spec: 'Board Level Repair', status: 'Active' }
  ];
  db.parts = [
    { id: 'p1', name: 'Samsung S21 Display', category: 'Display / Screen', compat: 'Samsung S21', stock: 3, minStock: 2, purchasePrice: 2500, sellPrice: 3500 },
    { id: 'p2', name: 'iPhone 13 Battery', category: 'Battery', compat: 'iPhone 13', stock: 5, minStock: 3, purchasePrice: 1200, sellPrice: 1800 },
    { id: 'p3', name: 'Universal Charging Port', category: 'Charging Port', compat: 'Universal', stock: 1, minStock: 3, purchasePrice: 150, sellPrice: 350 }
  ];
  const now = new Date();
  const d = (days) => new Date(now - days * 86400000).toISOString().split('T')[0];
  db.orders = [
    {
      id: 'RP-1000', date: d(5), phoneReceivedDate: d(5), phoneDeliveredDate: '',
      custName: 'Ramesh Gupta', custPhone: '9811223344', custEmail: 'ramesh@gmail.com',
      custAddress: 'Delhi', customerId: '', invoiceNo: 'INV-1000', custPhoto: null,
      deviceBrand: 'Samsung', deviceModel: 'Galaxy S21', imei: '358943085670234',
      deviceColor: 'Phantom Black', conditions: ['Screen Crack'],
      lockType: 'pin', lockCode: '1234', lockPatternNote: '',
      accessories: { sim: 'yes', cover: 'no', charger: 'yes', earphone: 'no' },
      selectedProblems: ['Display Replace'], repairNote: 'Handle with care',
      techId: 't1', techName: 'Rahul Sharma', priority: 'High',
      status: 'Completed', estimateAmt: 3500, advanceAmt: 1000, finalAmt: 3500,
      paymentStatus: 'Paid', notes: 'Done successfully', photo: null, createdAt: d(5)
    },
    {
      id: 'RP-1001', date: d(3), phoneReceivedDate: d(3), phoneDeliveredDate: d(1),
      custName: 'Priya Singh', custPhone: '9922334455', custEmail: '', custAddress: 'Noida',
      customerId: '', invoiceNo: 'INV-1001', custPhoto: null,
      deviceBrand: 'iPhone / Apple', deviceModel: 'iPhone 13', imei: '354987654321001',
      deviceColor: 'Blue', conditions: ['Normal Condition'],
      lockType: 'fingerprint', lockCode: '', lockPatternNote: '',
      accessories: { sim: 'yes', cover: 'yes', charger: 'no', earphone: 'no' },
      selectedProblems: ['Battery Replace'], repairNote: '',
      techId: 't2', techName: 'Amit Kumar', priority: 'Normal',
      status: 'Delivered', estimateAmt: 1800, advanceAmt: 500, finalAmt: 1800,
      paymentStatus: 'Paid', notes: '', photo: null, createdAt: d(3)
    },
    {
      id: 'RP-1002', date: d(2), phoneReceivedDate: d(2), phoneDeliveredDate: '',
      custName: 'Vikas Yadav', custPhone: '9733445566', custEmail: '', custAddress: 'Gurgaon',
      customerId: 'CUST-003', invoiceNo: 'INV-1002', custPhoto: null,
      deviceBrand: 'Xiaomi / Redmi', deviceModel: 'Redmi Note 12', imei: '', deviceColor: 'Gray',
      conditions: ['Water Damage', 'Body Damage'],
      lockType: 'pattern', lockCode: '', lockPatternNote: 'L-shape', lockPatternDots: [0, 3, 6, 7, 8],
      accessories: { sim: 'no', cover: 'no', charger: 'no', earphone: 'no' },
      selectedProblems: ['Water Damage', 'Charging Board Replace'], repairNote: 'Check motherboard carefully',
      techId: 't3', techName: 'Suresh Verma', priority: 'Urgent',
      status: 'In Progress', estimateAmt: 2000, advanceAmt: 800, finalAmt: 0,
      paymentStatus: 'Partial', notes: 'Waiting for board', photo: null, createdAt: d(2)
    },
    {
      id: 'RP-1003', date: d(1), phoneReceivedDate: d(1), phoneDeliveredDate: '',
      custName: 'Anita Rao', custPhone: '9644556677', custEmail: 'anita@gmail.com', custAddress: 'Faridabad',
      customerId: '', invoiceNo: 'INV-1003', custPhoto: null,
      deviceBrand: 'Realme', deviceModel: 'Realme 9 Pro', imei: '123456789012345',
      deviceColor: 'Sunrise Blue', conditions: ['Screen Crack'],
      lockType: 'pin', lockCode: '0000', lockPatternNote: '',
      accessories: { sim: 'yes', cover: 'yes', charger: 'yes', earphone: 'no' },
      selectedProblems: ['Display Replace'], repairNote: '',
      techId: 't1', techName: 'Rahul Sharma', priority: 'Normal',
      status: 'Pending', estimateAmt: 1200, advanceAmt: 0, finalAmt: 0,
      paymentStatus: 'Unpaid', notes: '', photo: null, createdAt: d(1)
    },
    {
      id: 'RP-1004', date: d(0), phoneReceivedDate: d(0), phoneDeliveredDate: '',
      custName: 'Mohit Sharma', custPhone: '9555667788', custEmail: '', custAddress: 'Ghaziabad',
      customerId: '', invoiceNo: 'INV-1004', custPhoto: null,
      deviceBrand: 'OnePlus', deviceModel: 'OnePlus 11', imei: '', deviceColor: 'Titan Black',
      conditions: [],
      lockType: 'none', lockCode: '', lockPatternNote: '',
      accessories: { sim: 'no', cover: 'no', charger: 'yes', earphone: 'no' },
      selectedProblems: ['Charging Pin Replace', 'Network Problem'], repairNote: 'USB-C port damaged',
      techId: 't2', techName: 'Amit Kumar', priority: 'High',
      status: 'Waiting for Parts', estimateAmt: 800, advanceAmt: 300, finalAmt: 0,
      paymentStatus: 'Partial', notes: 'Waiting for USB-C port', photo: null, createdAt: d(0)
    }
  ];
  orderCounter = 1005;
  saveDB();
}

// ============ NAVIGATION ============
function initNavigation() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(item.dataset.page);
    });
  });
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('collapsed');
    document.body.classList.toggle('sidebar-collapsed');
  });
}

function navigateTo(page) {
  document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
  const nav = document.querySelector(`.nav-item[data-page="${page}"]`);
  if (nav) nav.classList.add('active');

  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const pageEl = document.getElementById(`page-${page}`);
  if (pageEl) pageEl.classList.add('active');

  const titles = {
    'dashboard': 'Dashboard', 'orders': 'Repair Orders', 'new-order': 'New Repair Order',
    'inventory': 'Parts & Inventory', 'technicians': 'Technicians',
    'reports': 'Reports & Analytics', 'settings': 'Settings'
  };
  document.getElementById('pageTitle').textContent = titles[page] || page;

  if (page === 'dashboard') renderDashboard();
  if (page === 'orders') renderOrders();
  if (page === 'inventory') renderInventory();
  if (page === 'technicians') renderTechnicians();
  if (page === 'reports') loadReports();
  if (page === 'new-order') { populateTechDropdown(); }
  if (page === 'settings') loadSettings();
}

function setDate() {
  const now = new Date();
  document.getElementById('pageDate').textContent = now.toLocaleDateString('en-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

// ============ TOAST ============
function showToast(msg, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = `toast ${type} show`;
  setTimeout(() => toast.classList.remove('show'), 3500);
}

// ============ DASHBOARD ============
function renderDashboard() {
  const orders = db.orders;
  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();
  const monthOrders = orders.filter(o => {
    const d = new Date(o.date);
    return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
  });

  const total = orders.length;
  const pending = orders.filter(o => o.status === 'Pending').length;
  const completed = orders.filter(o => o.status === 'Completed' || o.status === 'Delivered').length;
  const revenue = monthOrders.reduce((s, o) => s + (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0), 0);
  const todayStr = now.toISOString().split('T')[0];
  const todayCount = orders.filter(o => (o.phoneReceivedDate || o.date) === todayStr).length;

  document.getElementById('statTotal').textContent = total;
  document.getElementById('statPending').textContent = pending;
  document.getElementById('statCompleted').textContent = completed;
  document.getElementById('statRevenue').textContent = '₹' + revenue.toLocaleString('en-IN');
  document.getElementById('statTotalTrend').textContent = `+${todayCount} today`;

  const statuses = ['Pending', 'In Progress', 'Waiting for Parts', 'Completed', 'Delivered'];
  const ids = ['bPending', 'bInProgress', 'bWaiting', 'bCompleted', 'bDelivered'];
  statuses.forEach((s, i) => {
    const el = document.getElementById(ids[i]);
    if (el) el.textContent = orders.filter(o => o.status === s).length;
  });

  const recent = [...orders].reverse().slice(0, 5);
  const tbody = document.getElementById('dashRecentBody');
  if (tbody) {
    tbody.innerHTML = recent.length === 0
      ? '<tr class="empty-row"><td colspan="5">No orders yet.</td></tr>'
      : recent.map(o => `
        <tr onclick="showOrderDetail('${o.id}')" style="cursor:pointer">
          <td><strong style="color:var(--accent-blue)">${o.id}</strong></td>
          <td>${o.custName}</td>
          <td>${o.deviceBrand} ${o.deviceModel}</td>
          <td>${statusBadge(o.status)}</td>
          <td>₹${(parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0).toLocaleString('en-IN')}</td>
        </tr>`).join('');
  }

  const lowStock = db.parts.filter(p => p.stock <= p.minStock);
  const lowStockEl = document.getElementById('lowStockList');
  if (lowStockEl) {
    lowStockEl.innerHTML = lowStock.length === 0
      ? '<div class="empty-state-sm">All parts in stock ✅</div>'
      : lowStock.map(p => `<div class="low-stock-item"><span>${p.name}</span><span class="badge badge-unpaid">Stock: ${p.stock}</span></div>`).join('');
  }

  updatePendingBadge();
}

function updatePendingBadge() {
  const count = db.orders.filter(o => o.status === 'Pending').length;
  const badge = document.getElementById('pendingBadge');
  if (badge) { badge.textContent = count; badge.style.display = count > 0 ? '' : 'none'; }
  const dot = document.getElementById('notifDot');
  if (dot) dot.style.display = count > 0 ? '' : 'none';
}

// ============ BADGES ============
function statusBadge(status) {
  const map = { 'Pending': 'badge-pending', 'In Progress': 'badge-inprogress', 'Waiting for Parts': 'badge-waiting', 'Completed': 'badge-completed', 'Delivered': 'badge-delivered' };
  const icons = { 'Pending': '⏳', 'In Progress': '🔧', 'Waiting for Parts': '📦', 'Completed': '✅', 'Delivered': '🚀' };
  return `<span class="badge ${map[status] || 'badge-normal'}">${icons[status] || ''} ${status}</span>`;
}

function payBadge(status) {
  const map = { 'Paid': 'badge-paid', 'Unpaid': 'badge-unpaid', 'Partial': 'badge-partial' };
  return `<span class="badge ${map[status] || ''}">${status}</span>`;
}

function priorityBadge(p) {
  const map = { 'Urgent': 'badge-urgent', 'High': 'badge-high', 'Normal': 'badge-normal' };
  return `<span class="badge ${map[p] || ''}">${p || 'Normal'}</span>`;
}

// ============ ORDERS LIST ============
function renderOrders(filterStatus = '', search = '') {
  let orders = [...db.orders].reverse();
  if (filterStatus) orders = orders.filter(o => o.status === filterStatus);
  if (search) {
    const s = search.toLowerCase();
    orders = orders.filter(o =>
      o.custName.toLowerCase().includes(s) ||
      o.custPhone.includes(s) ||
      o.deviceModel.toLowerCase().includes(s) ||
      o.deviceBrand.toLowerCase().includes(s) ||
      o.id.toLowerCase().includes(s)
    );
  }

  const tbody = document.getElementById('ordersBody');
  if (!tbody) return;

  if (orders.length === 0) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="9">No orders found.</td></tr>';
    return;
  }

  tbody.innerHTML = orders.map(o => {
    const problems = o.selectedProblems && o.selectedProblems.length > 0
      ? o.selectedProblems.slice(0, 2).join(', ') + (o.selectedProblems.length > 2 ? '...' : '')
      : (o.problemDesc || '—');
    return `
      <tr>
        <td><strong style="color:var(--accent-blue);cursor:pointer" onclick="showOrderDetail('${o.id}')">${o.id}</strong></td>
        <td>${formatDate(o.phoneReceivedDate || o.date)}</td>
        <td>
          <div style="font-weight:600">${o.custName}</div>
          <div style="font-size:12px;color:var(--text-secondary)">${o.custPhone}</div>
        </td>
        <td>
          <div style="font-weight:600">${o.deviceBrand}</div>
          <div style="font-size:12px;color:var(--text-secondary)">${o.deviceModel}</div>
        </td>
        <td style="max-width:160px;font-size:12px;color:var(--text-secondary)">${problems}</td>
        <td style="font-size:13px">${o.techName || '—'}</td>
        <td>${statusBadge(o.status)}</td>
        <td>
          <div style="font-weight:700">₹${(parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0).toLocaleString('en-IN')}</div>
          <div>${payBadge(o.paymentStatus)}</div>
        </td>
        <td>
          <div class="action-btns">
            <button class="btn btn-sm btn-outline" onclick="showOrderDetail('${o.id}')" title="View">👁️</button>
            <button class="btn btn-sm btn-outline" onclick="editOrder('${o.id}')" title="Edit">✏️</button>
            <button class="btn btn-sm btn-outline" onclick="generateInvoice('${o.id}')" title="Invoice">🧾</button>
            <button class="btn btn-sm btn-danger" onclick="deleteOrder('${o.id}')" title="Delete">🗑️</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

function initSearch() {
  const filterStatus = document.getElementById('filterStatus');
  const searchOrder = document.getElementById('searchOrder');
  const globalSearch = document.getElementById('globalSearch');

  if (filterStatus) filterStatus.addEventListener('change', () => renderOrders(filterStatus.value, searchOrder ? searchOrder.value : ''));
  if (searchOrder) searchOrder.addEventListener('input', () => renderOrders(filterStatus ? filterStatus.value : '', searchOrder.value));
  if (globalSearch) globalSearch.addEventListener('input', function () {
    if (this.value.length > 1) {
      navigateTo('orders');
      if (searchOrder) searchOrder.value = this.value;
      renderOrders('', this.value);
    }
  });
}

// ============ FORM INIT ============
function initForms() {
  const orderForm = document.getElementById('newOrderForm');
  if (orderForm) orderForm.addEventListener('submit', handleOrderSubmit);

  // Allow only digits and never more than 10 digits in customer phone field.
  const custPhone = document.getElementById('custPhone');
  if (custPhone) {
    custPhone.addEventListener('input', function () {
      const digits = this.value.replace(/\D/g, '').slice(0, 10);
      this.value = digits;
      this.setCustomValidity(digits.length === 10 ? '' : 'Please enter a valid 10-digit mobile number.');
    });
  }

  const partForm = document.getElementById('partForm');
  if (partForm) partForm.addEventListener('submit', handlePartSubmit);

  const techForm = document.getElementById('techForm');
  if (techForm) techForm.addEventListener('submit', handleTechSubmit);

  // Device photo upload
  const devicePhoto = document.getElementById('devicePhoto');
  if (devicePhoto) {
    devicePhoto.addEventListener('change', function () {
      const file = this.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => {
        const prev = document.getElementById('photoPreview');
        const ph = document.getElementById('photoPlaceholder');
        if (prev) { prev.src = e.target.result; prev.style.display = 'block'; }
        if (ph) ph.style.display = 'none';
      };
      reader.readAsDataURL(file);
    });
  }

  // Customer photo upload
  const custPhoto = document.getElementById('custPhotoInput');
  if (custPhoto) {
    custPhoto.addEventListener('change', function () {
      const file = this.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = e => {
        const prev = document.getElementById('custPhotoPreview');
        const ph = document.getElementById('custPhotoPlaceholder');
        if (prev) { prev.src = e.target.result; prev.style.display = 'block'; }
        if (ph) ph.style.display = 'none';
      };
      reader.readAsDataURL(file);
    });
  }

  // Set today's date
  const today = new Date().toISOString().split('T')[0];
  const recDate = document.getElementById('phoneReceivedDate');
  if (recDate) recDate.value = today;

  initPatternLock();
}

// ============ DEVICE BRAND -> MODEL DATA ============
const DEVICE_MODELS = {
  'Samsung': ['Galaxy S24 Ultra','Galaxy S24+','Galaxy S24','Galaxy S23 Ultra','Galaxy S23+','Galaxy S23','Galaxy S23 FE','Galaxy S22 Ultra','Galaxy S22+','Galaxy S22','Galaxy S21 Ultra','Galaxy S21+','Galaxy S21','Galaxy S21 FE','Galaxy S20 Ultra','Galaxy S20+','Galaxy S20','Galaxy S20 FE','Note 20 Ultra','Note 20','Note 10+','Note 10','Note 9','Z Fold 6','Z Fold 5','Z Fold 4','Z Flip 6','Z Flip 5','Z Flip 4','A55','A54','A53','A52','A51','A34','A33','A32','A25','A24','A23','A15','A14','A13','A12','A05','A05s','A04','A03','A03 Core','M54','M53','M34','M33','M14','M13','M04','F54','F14','Tab S9','Tab S8','Tab A9'],
  'iPhone / Apple': ['iPhone 16 Pro Max','iPhone 16 Pro','iPhone 16 Plus','iPhone 16','iPhone 15 Pro Max','iPhone 15 Pro','iPhone 15 Plus','iPhone 15','iPhone 14 Pro Max','iPhone 14 Pro','iPhone 14 Plus','iPhone 14','iPhone 13 Pro Max','iPhone 13 Pro','iPhone 13 mini','iPhone 13','iPhone 12 Pro Max','iPhone 12 Pro','iPhone 12 mini','iPhone 12','iPhone 11 Pro Max','iPhone 11 Pro','iPhone 11','iPhone XS Max','iPhone XS','iPhone XR','iPhone X','iPhone 8 Plus','iPhone 8','iPhone 7 Plus','iPhone 7','iPhone 6s Plus','iPhone 6s','iPhone 6 Plus','iPhone 6','iPhone SE (2022)','iPhone SE (2020)','iPad'],
  'Xiaomi / Redmi': ['Redmi Note 13 Pro+','Redmi Note 13 Pro','Redmi Note 13','Redmi Note 12 Pro+','Redmi Note 12 Pro','Redmi Note 12','Redmi Note 11 Pro+','Redmi Note 11 Pro','Redmi Note 11','Redmi Note 10 Pro','Redmi Note 10','Redmi 13C','Redmi 12','Redmi 12C','Redmi 10','Redmi 9','Redmi 9A','Redmi K50','Redmi K60','Xiaomi 14','Xiaomi 13','Xiaomi 13 Pro','Xiaomi 12','Xiaomi 11','Poco X6 Pro','Poco X6','Poco X5 Pro','Poco X5','Poco F5','Poco F6','Poco M6','Poco M6 Pro','Poco C65'],
  'Realme': ['Realme 12 Pro+','Realme 12 Pro','Realme 12','Realme 11 Pro+','Realme 11 Pro','Realme 11','Realme 10 Pro+','Realme 10 Pro','Realme 10','Realme 9 Pro+','Realme 9 Pro','Realme 9','Realme 8 Pro','Realme 8','Realme 7 Pro','Realme 7','Realme C55','Realme C53','Realme C51','Realme C35','Realme C33','Realme C30','Realme C25','Realme GT Neo 5','Realme GT Neo 3','Realme GT 2 Pro','Realme Narzo 70','Realme Narzo 60','Realme Narzo 50'],
  'OnePlus': ['OnePlus 12','OnePlus 12R','OnePlus 11','OnePlus 11R','OnePlus 10 Pro','OnePlus 10T','OnePlus 10R','OnePlus 9 Pro','OnePlus 9','OnePlus 9R','OnePlus 9RT','OnePlus 8 Pro','OnePlus 8T','OnePlus 8','OnePlus Nord 4','OnePlus Nord 3','OnePlus Nord CE 4','OnePlus Nord CE 3','OnePlus Nord CE 2','OnePlus Nord 2','OnePlus Nord'],
  'Vivo': ['Vivo V30 Pro','Vivo V30','Vivo V29 Pro','Vivo V29','Vivo V27 Pro','Vivo V27','Vivo V25 Pro','Vivo V25','Vivo V23 Pro','Vivo V23','Vivo Y100','Vivo Y56','Vivo Y36','Vivo Y27','Vivo Y21','Vivo Y20','Vivo Y17s','Vivo T3','Vivo T3x','Vivo T2','Vivo T1','Vivo X100','Vivo X90','Vivo X80'],
  'OPPO': ['Reno 11 Pro','Reno 11','Reno 10 Pro+','Reno 10 Pro','Reno 10','Reno 8T','Reno 8','Reno 7','Reno 6','A98','A78','A77','A58','A57','A38','A18','A17','A16','A15','A15s','F25 Pro','F23','F21 Pro','F19 Pro','K11','Find X7','Find X6','Find N3'],
  'Motorola': ['Moto G84','Moto G73','Moto G54','Moto G34','Moto G32','Moto G62','Edge 50 Pro','Edge 50','Edge 40','Edge 40 Pro','Edge 30','Razr 40 Ultra','Razr 40','Moto E13','Moto E22','Moto E32'],
  'Nokia': ['Nokia G42','Nokia G22','Nokia G21','Nokia C32','Nokia C22','Nokia C12','Nokia X30','Nokia X20','Nokia 105','Nokia 110','Nokia 150','Nokia 5310','Nokia 6300 4G','Nokia 8210 4G'],
  'Tecno': ['Camon 30','Camon 20 Pro','Camon 19','Spark 20','Spark 10','Spark 9','Pova 6','Pova 5','Pova 4','Phantom X2','Phantom V Fold','Pop 8','Pop 7'],
  'Infinix': ['Note 40 Pro','Note 30 Pro','Note 12','Hot 40','Hot 30','Hot 12','Zero 30','Zero Ultra','Smart 8','Smart 7','GT 10 Pro'],
  'iQOO': ['iQOO 12','iQOO 12 Pro','iQOO 11','iQOO 11 Pro','iQOO Z9','iQOO Z7','iQOO Z6','iQOO Neo 9','iQOO Neo 7','iQOO Neo 6','iQOO 9T','iQOO 9 SE','iQOO 7']
};

function populateDeviceModels(selectedModel) {
  const brand = document.getElementById('deviceBrand').value;
  const modelSel = document.getElementById('deviceModel');
  const otherInput = document.getElementById('deviceModelOther');
  if (!modelSel) return;

  otherInput.style.display = 'none';
  otherInput.value = '';

  if (!brand) {
    modelSel.innerHTML = '<option value="">Pehle brand select karo</option>';
    modelSel.disabled = true;
    return;
  }

  modelSel.disabled = false;
  const models = DEVICE_MODELS[brand] || [];
  let optionsHtml = '<option value="">Select Model</option>';
  optionsHtml += models.map(m => `<option value="${m}">${m}</option>`).join('');
  optionsHtml += '<option value="__other__">Other / Model list me nahi hai</option>';
  modelSel.innerHTML = optionsHtml;

  if (selectedModel) {
    if (models.includes(selectedModel)) {
      modelSel.value = selectedModel;
    } else {
      modelSel.value = '__other__';
      otherInput.style.display = 'block';
      otherInput.value = selectedModel;
    }
  }
}

function toggleDeviceModelOther() {
  const modelSel = document.getElementById('deviceModel');
  const otherInput = document.getElementById('deviceModelOther');
  if (!modelSel || !otherInput) return;
  if (modelSel.value === '__other__') {
    otherInput.style.display = 'block';
    otherInput.focus();
  } else {
    otherInput.style.display = 'none';
    otherInput.value = '';
  }
}

function getDeviceModelValue() {
  const modelSel = document.getElementById('deviceModel');
  const otherInput = document.getElementById('deviceModelOther');
  if (!modelSel) return '';
  if (modelSel.value === '__other__') return (otherInput ? otherInput.value.trim() : '');
  return modelSel.value;
}

// ============ PATTERN LOCK (visual 3x3 draw + preview) ============
const PATTERN_DOT_COORDS = [
  [40, 40], [120, 40], [200, 40],
  [40, 120], [120, 120], [200, 120],
  [40, 200], [120, 200], [200, 200]
];
let patternDrawing = false;
let patternDots = [];

function initPatternLock() {
  const grid = document.getElementById('patternLockGrid');
  if (!grid || grid.dataset.bound) return;
  grid.dataset.bound = '1';

  const dots = [...grid.querySelectorAll('.pattern-dot')];

  function dotAtPoint(clientX, clientY) {
    const gridRect = grid.getBoundingClientRect();
    for (const dot of dots) {
      const r = dot.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const dx = clientX - cx, dy = clientY - cy;
      if (Math.sqrt(dx * dx + dy * dy) < r.width * 0.9) return dot;
    }
    return null;
  }

  function addDot(dot) {
    const idx = parseInt(dot.dataset.idx, 10);
    if (patternDots.includes(idx)) return;
    patternDots.push(idx);
    dot.classList.add('active');
    renderPatternLines();
  }

  function startDraw(clientX, clientY) {
    patternDrawing = true;
    patternDots = [];
    dots.forEach(d => d.classList.remove('active'));
    const dot = dotAtPoint(clientX, clientY);
    if (dot) addDot(dot);
  }

  function moveDraw(clientX, clientY) {
    if (!patternDrawing) return;
    const dot = dotAtPoint(clientX, clientY);
    if (dot) addDot(dot);
  }

  function endDraw() {
    if (!patternDrawing) return;
    patternDrawing = false;
    const hidden = document.getElementById('lockPatternDots');
    if (hidden) hidden.value = JSON.stringify(patternDots);
  }

  grid.addEventListener('pointerdown', e => { e.preventDefault(); startDraw(e.clientX, e.clientY); });
  window.addEventListener('pointermove', e => { if (patternDrawing) moveDraw(e.clientX, e.clientY); });
  window.addEventListener('pointerup', endDraw);
  grid.addEventListener('touchstart', e => { e.preventDefault(); const t = e.touches[0]; startDraw(t.clientX, t.clientY); }, { passive: false });
  grid.addEventListener('touchmove', e => { e.preventDefault(); const t = e.touches[0]; moveDraw(t.clientX, t.clientY); }, { passive: false });
  grid.addEventListener('touchend', endDraw);
}

function renderPatternLines() {
  const svg = document.getElementById('patternLockLines');
  if (!svg) return;
  if (patternDots.length < 2) { svg.innerHTML = ''; return; }
  const pts = patternDots.map(i => PATTERN_DOT_COORDS[i].join(',')).join(' ');
  svg.innerHTML = `<polyline points="${pts}" fill="none" stroke="var(--accent-amber)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" />`;
}

function clearPatternLock() {
  patternDots = [];
  patternDrawing = false;
  document.querySelectorAll('#patternLockGrid .pattern-dot').forEach(d => d.classList.remove('active'));
  renderPatternLines();
  const hidden = document.getElementById('lockPatternDots');
  if (hidden) hidden.value = '';
}

function setPatternDots(arr) {
  clearPatternLock();
  if (!arr || !arr.length) return;
  patternDots = [...arr];
  const grid = document.getElementById('patternLockGrid');
  if (grid) {
    patternDots.forEach(i => {
      const dot = grid.querySelector(`.pattern-dot[data-idx="${i}"]`);
      if (dot) dot.classList.add('active');
    });
  }
  renderPatternLines();
  const hidden = document.getElementById('lockPatternDots');
  if (hidden) hidden.value = JSON.stringify(patternDots);
}

// Static+animated SVG preview of a saved pattern, used in the repair-manager order view.
// Numbered dots show the draw order; the line "replays" (like a recording) so staff
// can see exactly how the customer's finger moved, not just the final shape.
function renderPatternPreviewSVG(dotsArr, size, svgId) {
  size = size || 110;
  svgId = svgId || ('plv-' + Math.random().toString(36).slice(2));
  if (!dotsArr || dotsArr.length === 0) {
    return { html: `<div class="pattern-lock-view-empty">Pattern draw nahi kiya gaya</div>`, svgId: null };
  }
  const scale = size / 240;
  const dotsHtml = PATTERN_DOT_COORDS.map((c, i) => {
    const active = dotsArr.includes(i);
    const order = dotsArr.indexOf(i);
    const label = active ? `<text x="${c[0] * scale}" y="${c[1] * scale}" class="plv-num" dy="0.35em">${order + 1}</text>` : '';
    return `<circle cx="${c[0] * scale}" cy="${c[1] * scale}" r="${9 * scale}" class="${active ? 'plv-dot-active' : 'plv-dot'}" />${label}`;
  }).join('');
  const pts = dotsArr.map(i => `${PATTERN_DOT_COORDS[i][0] * scale},${PATTERN_DOT_COORDS[i][1] * scale}`).join(' ');
  const html = `<svg id="${svgId}" class="pattern-lock-view" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
    <polyline points="${pts}" fill="none" class="plv-line" stroke-width="${4 * scale}" stroke-linecap="round" stroke-linejoin="round" />
    ${dotsHtml}
  </svg>`;
  return { html, svgId };
}

// Replays the pattern draw like a screen recording: the line traces itself from
// dot 1 to the last dot over ~1.5s. Called automatically when an order opens, and
// again whenever the "Replay" button is tapped.
function animatePatternPreview(svgId) {
  const svg = document.getElementById(svgId);
  if (!svg) return;
  const poly = svg.querySelector('polyline');
  if (!poly) return;
  const length = poly.getTotalLength();
  poly.style.transition = 'none';
  poly.style.strokeDasharray = length;
  poly.style.strokeDashoffset = length;
  // force reflow so the browser registers the reset before animating
  poly.getBoundingClientRect();
  poly.style.transition = 'stroke-dashoffset 1.5s ease';
  requestAnimationFrame(() => { poly.style.strokeDashoffset = '0'; });
}

function populateTechDropdown() {
  const sel = document.getElementById('assignedTech');
  if (!sel) return;
  sel.innerHTML = '<option value="">Select Technician</option>' +
    db.technicians.filter(t => t.status === 'Active').map(t =>
      `<option value="${t.id}">${t.name} — ${t.spec}</option>`
    ).join('');
}

// ============ LOCK TYPE TOGGLE ============
function setLockType(type) {
  const lockTypeEl = document.getElementById('lockType');
  if (lockTypeEl) lockTypeEl.value = type;

  ['None', 'Pin', 'Pattern', 'Finger'].forEach(t => {
    const btn = document.getElementById('lockType' + t);
    if (btn) btn.classList.remove('active');
  });
  const map = { none: 'lockTypeNone', pin: 'lockTypePin', pattern: 'lockTypePattern', fingerprint: 'lockTypeFinger' };
  const activeBtn = document.getElementById(map[type]);
  if (activeBtn) activeBtn.classList.add('active');

  const codeRow = document.getElementById('lockCodeRow');
  const patternInfo = document.getElementById('lockPatternInfo');
  if (codeRow) codeRow.style.display = type === 'pin' ? 'block' : 'none';
  if (patternInfo) patternInfo.style.display = type === 'pattern' ? 'block' : 'none';
}

// ============ PROBLEM TAG TOGGLE ============
function toggleProblem(el) {
  el.classList.toggle('selected');
  updateSelectedProblems();
}

function updateSelectedProblems() {
  const selected = [...document.querySelectorAll('.prob-tag.selected')].map(el => el.dataset.val);
  const display = document.getElementById('selectedProblemsDisplay');
  const chips = document.getElementById('selectedProblemsChips');
  if (!display || !chips) return;
  if (selected.length === 0) {
    display.style.display = 'none';
  } else {
    display.style.display = 'flex';
    chips.innerHTML = selected.map(s => `<span class="prob-chip">${s}</span>`).join('');
  }
}

function getSelectedProblems() {
  return [...document.querySelectorAll('.prob-tag.selected')].map(el => el.dataset.val);
}

function setSelectedProblems(problems) {
  document.querySelectorAll('.prob-tag').forEach(el => {
    el.classList.toggle('selected', problems && problems.includes(el.dataset.val));
  });
  updateSelectedProblems();
}

function clearCustPhoto() {
  const prev = document.getElementById('custPhotoPreview');
  const ph = document.getElementById('custPhotoPlaceholder');
  const input = document.getElementById('custPhotoInput');
  if (prev) { prev.style.display = 'none'; prev.src = ''; }
  if (ph) ph.style.display = 'flex';
  if (input) input.value = '';
}

// ============ HANDLE ORDER SUBMIT ============
function handleOrderSubmit(e) {
  e.preventDefault();

  // Customer phone must contain exactly 10 digits.
  const phoneInput = document.getElementById('custPhone');
  const phone = phoneInput ? phoneInput.value.replace(/\D/g, '') : '';
  if (phoneInput) phoneInput.value = phone.slice(0, 10);
  if (phone.length !== 10) {
    if (phoneInput) {
      phoneInput.setCustomValidity('Please enter a valid 10-digit mobile number.');
      phoneInput.reportValidity();
      phoneInput.focus();
    }
    return;
  }
  if (phoneInput) phoneInput.setCustomValidity('');

  // Validate at least one problem selected
  const selectedProblems = getSelectedProblems();
  if (selectedProblems.length === 0) {
    showToast('⚠️ Kam se kam ek problem select karo!', 'error');
    const pg = document.getElementById('problemGrid');
    if (pg) pg.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  // Get all field values safely
  function val(id) { const el = document.getElementById(id); return el ? el.value.trim() : ''; }
  function numVal(id) { return parseFloat(val(id)) || 0; }

  const conditions = [...document.querySelectorAll('input[name="condition"]:checked')].map(c => c.value);
  const techId = val('assignedTech');
  const tech = db.technicians.find(t => t.id === techId);

  const photoEl = document.getElementById('photoPreview');
  const photo = (photoEl && photoEl.style.display !== 'none' && photoEl.src) ? photoEl.src : null;

  const custPhotoEl = document.getElementById('custPhotoPreview');
  const custPhoto = (custPhotoEl && custPhotoEl.style.display !== 'none' && custPhotoEl.src) ? custPhotoEl.src : null;

  const lockType = val('lockType') || 'none';
  const lockCode = val('lockCode');
  const lockPatternNote = val('lockPatternNote');
  let lockPatternDots = [];
  try { lockPatternDots = JSON.parse(val('lockPatternDots') || '[]'); } catch (e) { lockPatternDots = []; }

  const accSim = (document.querySelector('input[name="accSim"]:checked') || {}).value || 'no';
  const accCover = (document.querySelector('input[name="accCover"]:checked') || {}).value || 'no';
  const accCharger = (document.querySelector('input[name="accCharger"]:checked') || {}).value || 'no';
  const accEarphone = (document.querySelector('input[name="accEarphone"]:checked') || {}).value || 'no';

  const editId = val('editOrderId');
  const today = new Date().toISOString().split('T')[0];

  let invoiceNo = val('invoiceNo');
  if (!invoiceNo) invoiceNo = editId ? editId.replace('RP-', 'INV-') : `INV-${orderCounter}`;

  const orderData = {
    custName: val('custName'),
    custPhone: val('custPhone'),
    custEmail: val('custEmail'),
    custAddress: val('custAddress'),
    customerId: val('customerId'),
    invoiceNo,
    custPhoto,
    deviceBrand: val('deviceBrand'),
    deviceModel: getDeviceModelValue(),
    imei: val('imeiNumber'),
    deviceColor: val('deviceColor'),
    phoneReceivedDate: val('phoneReceivedDate') || today,
    phoneDeliveredDate: val('phoneDeliveredDate'),
    lockType,
    lockCode,
    lockPatternNote,
    lockPatternDots,
    conditions,
    accessories: { sim: accSim, cover: accCover, charger: accCharger, earphone: accEarphone },
    selectedProblems,
    repairNote: val('repairNote'),
    techId,
    techName: tech ? tech.name : '',
    priority: val('priority') || 'Normal',
    status: val('orderStatus') || 'Pending',
    estimateAmt: numVal('estimateAmt'),
    advanceAmt: numVal('advanceAmt'),
    finalAmt: numVal('finalAmt'),
    paymentStatus: val('paymentStatus') || 'Unpaid',
    notes: val('notes'),
    photo
  };

  if (editId) {
    const idx = db.orders.findIndex(o => o.id === editId);
    if (idx !== -1) {
      db.orders[idx] = { ...db.orders[idx], ...orderData };
      showToast(`✅ Order ${editId} update ho gaya!`, 'success');
    }
  } else {
    const id = `RP-${orderCounter++}`;
    db.orders.push({ id, date: today, createdAt: today, invoiceNo, ...orderData });
    showToast(`✅ Order ${id} create ho gaya!`, 'success');
  }

  saveDB();
  renderDashboard();
  resetForm();
  navigateTo('orders');
}

// ============ EDIT ORDER ============
function editOrder(id) {
  const o = db.orders.find(x => x.id === id);
  if (!o) return;
  closeModal('orderDetailModal');
  navigateTo('new-order');
  populateTechDropdown();

  setTimeout(() => {
    function setVal(elId, v) { const el = document.getElementById(elId); if (el) el.value = v || ''; }

    setVal('editOrderId', o.id);
    const btn = document.getElementById('submitOrderBtn');
    if (btn) btn.textContent = '✅ Update Order';

    setVal('custName', o.custName);
    setVal('custPhone', o.custPhone);
    setVal('custEmail', o.custEmail);
    setVal('custAddress', o.custAddress);
    setVal('customerId', o.customerId);
    setVal('invoiceNo', o.invoiceNo);
    setVal('deviceBrand', o.deviceBrand);
    populateDeviceModels(o.deviceModel);
    setVal('imeiNumber', o.imei);
    setVal('deviceColor', o.deviceColor);
    setVal('phoneReceivedDate', o.phoneReceivedDate || o.date);
    setVal('phoneDeliveredDate', o.phoneDeliveredDate);
    setVal('assignedTech', o.techId);
    setVal('priority', o.priority || 'Normal');
    setVal('orderStatus', o.status);
    setVal('estimateAmt', o.estimateAmt);
    setVal('advanceAmt', o.advanceAmt);
    setVal('finalAmt', o.finalAmt);
    setVal('paymentStatus', o.paymentStatus);
    setVal('notes', o.notes);
    setVal('repairNote', o.repairNote);

    setLockType(o.lockType || 'none');
    setVal('lockCode', o.lockCode);
    setVal('lockPatternNote', o.lockPatternNote);
    setPatternDots(o.lockPatternDots || []);

    document.querySelectorAll('input[name="condition"]').forEach(cb => {
      cb.checked = o.conditions && o.conditions.includes(cb.value);
    });

    if (o.accessories) {
      const setRadio = (name, val) => {
        const el = document.querySelector(`input[name="${name}"][value="${val || 'no'}"]`);
        if (el) el.checked = true;
      };
      setRadio('accSim', o.accessories.sim);
      setRadio('accCover', o.accessories.cover);
      setRadio('accCharger', o.accessories.charger);
      setRadio('accEarphone', o.accessories.earphone);
    }

    setSelectedProblems(o.selectedProblems || []);

    if (o.photo) {
      const prev = document.getElementById('photoPreview');
      const ph = document.getElementById('photoPlaceholder');
      if (prev) { prev.src = o.photo; prev.style.display = 'block'; }
      if (ph) ph.style.display = 'none';
    }
    if (o.custPhoto) {
      const prev = document.getElementById('custPhotoPreview');
      const ph = document.getElementById('custPhotoPlaceholder');
      if (prev) { prev.src = o.custPhoto; prev.style.display = 'block'; }
      if (ph) ph.style.display = 'none';
    }
  }, 150);
}

function deleteOrder(id) {
  if (!confirm(`Order ${id} delete karna chahte ho? Yeh undo nahi hoga.`)) return;
  db.orders = db.orders.filter(o => o.id !== id);
  saveDB();
  renderDashboard();
  renderOrders();
  closeModal('orderDetailModal');
  showToast(`Order ${id} delete ho gaya.`, 'error');
}

function resetForm() {
  const form = document.getElementById('newOrderForm');
  if (form) form.reset();

  const editOrderId = document.getElementById('editOrderId');
  if (editOrderId) editOrderId.value = '';

  const btn = document.getElementById('submitOrderBtn');
  if (btn) btn.textContent = '✅ Create Repair Order';

  const prev = document.getElementById('photoPreview');
  const ph = document.getElementById('photoPlaceholder');
  if (prev) { prev.style.display = 'none'; prev.src = ''; }
  if (ph) ph.style.display = 'flex';

  const cprev = document.getElementById('custPhotoPreview');
  const cph = document.getElementById('custPhotoPlaceholder');
  if (cprev) { cprev.style.display = 'none'; cprev.src = ''; }
  if (cph) cph.style.display = 'flex';

  setLockType('none');
  clearPatternLock();
  populateDeviceModels();
  document.querySelectorAll('.prob-tag').forEach(t => t.classList.remove('selected'));
  updateSelectedProblems();

  const recDate = document.getElementById('phoneReceivedDate');
  if (recDate) recDate.value = new Date().toISOString().split('T')[0];
}

// ============ ORDER DETAIL MODAL ============
function showOrderDetail(id) {
  const o = db.orders.find(x => x.id === id);
  if (!o) return;

  const balance = (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0) - (parseFloat(o.advanceAmt) || 0);
  const lockIcons = { none: '🔓 No Lock', pin: '🔢 PIN/Password', pattern: '⬛ Pattern Lock', fingerprint: '👆 Fingerprint' };
  const lockDisplay = (lockIcons[o.lockType || 'none'] || '🔓') +
    (o.lockCode ? ` — Code: <strong>${o.lockCode}</strong>` : '') +
    (o.lockPatternNote ? ` (${o.lockPatternNote})` : '');
  let lockPatternPreview = '';
  let patternSvgId = null;
  if (o.lockType === 'pattern') {
    const preview = renderPatternPreviewSVG(o.lockPatternDots, 110, `plv-${o.id}`);
    patternSvgId = preview.svgId;
    lockPatternPreview = `<div style="margin-top:8px;display:flex;align-items:center;gap:10px">
      ${preview.html}
      ${patternSvgId ? `<button type="button" class="btn btn-sm btn-outline" onclick="animatePatternPreview('${patternSvgId}')">▶ Replay</button>` : ''}
    </div>`;
  }

  const acc = o.accessories || {};
  const accDisplay = [
    acc.sim === 'yes' ? '✅ SIM/Memory' : '❌ SIM/Memory',
    acc.cover === 'yes' ? '✅ Back Cover' : '❌ Back Cover',
    acc.charger === 'yes' ? '✅ Charger' : '❌ Charger',
    acc.earphone === 'yes' ? '✅ Earphones' : '❌ Earphones',
  ].join('&nbsp;&nbsp;');

  const problems = o.selectedProblems && o.selectedProblems.length > 0
    ? o.selectedProblems.map(p => `<span class="prob-chip">${p}</span>`).join('')
    : (o.problemDesc ? `<span>${o.problemDesc}</span>` : '—');

  const statuses = ['Pending', 'In Progress', 'Waiting for Parts', 'Completed', 'Delivered'];

  document.getElementById('modalOrderTitle').textContent = `${o.id} — ${o.custName}`;
  document.getElementById('orderDetailBody').innerHTML = `
    <div class="order-detail">
      <div class="detail-section">
        <div class="detail-section-title">🔄 Repair Status Update karo</div>
        <div class="status-update-bar">
          ${statuses.map(s => `<button class="status-btn ${o.status === s ? 'active-status' : ''}" onclick="updateStatus('${id}','${s}',this)">${s}</button>`).join('')}
        </div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">👤 Customer Information</div>
        <div class="detail-grid">
          <div class="detail-item"><div class="detail-label">Naam</div><div class="detail-value">${o.custName}</div></div>
          <div class="detail-item"><div class="detail-label">Phone</div><div class="detail-value"><a href="tel:${o.custPhone}" style="color:var(--accent-blue)">${o.custPhone}</a></div></div>
          <div class="detail-item"><div class="detail-label">Email</div><div class="detail-value">${o.custEmail || '—'}</div></div>
          <div class="detail-item"><div class="detail-label">Address</div><div class="detail-value">${o.custAddress || '—'}</div></div>
          ${o.customerId ? `<div class="detail-item"><div class="detail-label">Customer ID</div><div class="detail-value">${o.customerId}</div></div>` : ''}
          <div class="detail-item"><div class="detail-label">Invoice No.</div><div class="detail-value" style="color:var(--accent-blue);font-weight:700">${o.invoiceNo || '—'}</div></div>
        </div>
        ${o.custPhoto ? `<div style="padding:12px 16px"><img src="${o.custPhoto}" style="max-height:100px;border-radius:8px;object-fit:cover" alt="Customer" /></div>` : ''}
      </div>

      <div class="detail-section">
        <div class="detail-section-title">📱 Device Information</div>
        <div class="detail-grid">
          <div class="detail-item"><div class="detail-label">Brand</div><div class="detail-value">${o.deviceBrand}</div></div>
          <div class="detail-item"><div class="detail-label">Model</div><div class="detail-value">${o.deviceModel}</div></div>
          <div class="detail-item"><div class="detail-label">IMEI</div><div class="detail-value" style="font-family:monospace">${o.imei || '—'}</div></div>
          <div class="detail-item"><div class="detail-label">Color</div><div class="detail-value">${o.deviceColor || '—'}</div></div>
          <div class="detail-item"><div class="detail-label">📅 Phone Diya</div><div class="detail-value" style="color:var(--accent-blue);font-weight:600">${formatDate(o.phoneReceivedDate || o.date)}</div></div>
          <div class="detail-item"><div class="detail-label">📅 Phone Liya</div><div class="detail-value" style="color:${o.phoneDeliveredDate ? 'var(--accent-green)' : 'var(--text-muted)'};font-weight:600">${o.phoneDeliveredDate ? formatDate(o.phoneDeliveredDate) : 'Abhi nahi mila'}</div></div>
          <div class="detail-item" style="${o.lockType === 'pattern' ? 'grid-column:1/-1' : ''}"><div class="detail-label">🔐 Lock</div><div class="detail-value">${lockDisplay}</div>${lockPatternPreview}</div>
          <div class="detail-item"><div class="detail-label">Condition</div><div class="detail-value">${o.conditions && o.conditions.length > 0 ? o.conditions.join(', ') : 'Normal'}</div></div>
          <div class="detail-item"><div class="detail-label">Priority</div><div class="detail-value">${priorityBadge(o.priority)}</div></div>
          <div class="detail-item" style="grid-column:1/-1"><div class="detail-label">📦 Accessories</div><div class="detail-value" style="font-size:13px">${accDisplay}</div></div>
        </div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">🛠️ Repair Details</div>
        <div class="detail-grid">
          <div class="detail-item" style="grid-column:1/-1">
            <div class="detail-label">Problems / Kaam</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px">${problems}</div>
          </div>
          ${o.repairNote ? `<div class="detail-item" style="grid-column:1/-1"><div class="detail-label">📝 Note</div><div class="detail-value">${o.repairNote}</div></div>` : ''}
          <div class="detail-item"><div class="detail-label">Technician</div><div class="detail-value">${o.techName || '—'}</div></div>
          ${o.notes ? `<div class="detail-item"><div class="detail-label">Internal Notes</div><div class="detail-value">${o.notes}</div></div>` : ''}
        </div>
      </div>

      <div class="detail-section">
        <div class="detail-section-title">💰 Billing & Payment</div>
        <div class="detail-grid">
          <div class="detail-item"><div class="detail-label">Estimate</div><div class="detail-value">₹${parseFloat(o.estimateAmt || 0).toLocaleString('en-IN')}</div></div>
          <div class="detail-item"><div class="detail-label">Final Amount</div><div class="detail-value" style="font-size:16px;font-weight:800;color:var(--accent-green)">₹${parseFloat(o.finalAmt || 0).toLocaleString('en-IN')}</div></div>
          <div class="detail-item"><div class="detail-label">Advance</div><div class="detail-value">₹${parseFloat(o.advanceAmt || 0).toLocaleString('en-IN')}</div></div>
          <div class="detail-item"><div class="detail-label">Balance Due</div><div class="detail-value" style="color:${balance > 0 ? 'var(--accent-red)' : 'var(--accent-green)'};font-weight:700">₹${balance.toLocaleString('en-IN')}</div></div>
          <div class="detail-item"><div class="detail-label">Payment</div><div class="detail-value">${payBadge(o.paymentStatus)}</div></div>
          <div class="detail-item"><div class="detail-label">Date</div><div class="detail-value">${formatDate(o.date)}</div></div>
        </div>
      </div>

      ${o.photo ? `<div class="detail-section"><div class="detail-section-title">📷 Device Photo</div><div style="padding:16px"><img src="${o.photo}" style="max-width:100%;max-height:220px;border-radius:8px;object-fit:cover" /></div></div>` : ''}

      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:4px">
        <button class="btn btn-primary" onclick="generateInvoice('${o.id}')">🧾 Invoice</button>
        <button class="btn btn-outline" onclick="editOrder('${o.id}')">✏️ Edit</button>
        <button class="btn btn-green" onclick="sendWhatsApp('${o.id}')">💬 WhatsApp</button>
        <button class="btn btn-danger" onclick="deleteOrder('${o.id}')">🗑️ Delete</button>
      </div>
    </div>`;

  openModal('orderDetailModal');
  if (patternSvgId) setTimeout(() => animatePatternPreview(patternSvgId), 250);
}

function updateStatus(id, status, btn) {
  const order = db.orders.find(o => o.id === id);
  if (!order) return;
  order.status = status;
  if (status === 'Delivered') {
    order.phoneDeliveredDate = new Date().toISOString().split('T')[0];
  }
  saveDB();
  btn.closest('.status-update-bar').querySelectorAll('.status-btn').forEach(b => b.classList.remove('active-status'));
  btn.classList.add('active-status');
  showToast(`Status: "${status}" ho gaya!`, 'success');
  renderDashboard();
  if (document.getElementById('page-orders').classList.contains('active')) renderOrders();
}

// ============ INVOICE ============
function generateInvoice(id) {
  const o = db.orders.find(x => x.id === id);
  if (!o) return;
  const s = db.settings;
  const finalAmt = parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0;
  const advance = parseFloat(o.advanceAmt) || 0;
  const balance = finalAmt - advance;
  const problems = o.selectedProblems && o.selectedProblems.length > 0
    ? o.selectedProblems.join(', ')
    : (o.problemDesc || '—');

  document.getElementById('invoiceBody').innerHTML = `
    <div class="invoice-print">
      <div class="invoice-head">
        <div>
          <div class="invoice-shop-name">${s.shopName || 'Repair Shop'}</div>
          <div class="invoice-shop-details">
            ${s.ownerName ? `Owner: ${s.ownerName}<br>` : ''}
            ${s.phone ? `📞 ${s.phone}<br>` : ''}
            ${s.address ? `📍 ${s.address}<br>` : ''}
            ${s.gst ? `GST: ${s.gst}` : ''}
          </div>
        </div>
        <div class="invoice-title-block">
          <div class="invoice-title">INVOICE</div>
          <div class="invoice-num">Invoice: ${o.invoiceNo || o.id}</div>
          <div class="invoice-date">Order: ${o.id}</div>
          <div class="invoice-date">Date: ${formatDate(o.phoneReceivedDate || o.date)}</div>
          ${o.phoneDeliveredDate ? `<div class="invoice-date">Delivered: ${formatDate(o.phoneDeliveredDate)}</div>` : ''}
        </div>
      </div>
      <hr class="invoice-divider" />
      <div class="invoice-parties">
        <div class="invoice-party">
          <h4>Customer</h4>
          <p class="party-name">${o.custName}</p>
          <p>📞 ${o.custPhone}</p>
          ${o.custEmail ? `<p>✉️ ${o.custEmail}</p>` : ''}
          ${o.custAddress ? `<p>📍 ${o.custAddress}</p>` : ''}
          ${o.customerId ? `<p>ID: ${o.customerId}</p>` : ''}
        </div>
        <div class="invoice-party">
          <h4>Device Details</h4>
          <p class="party-name">${o.deviceBrand} ${o.deviceModel}</p>
          ${o.imei ? `<p>IMEI: ${o.imei}</p>` : ''}
          ${o.deviceColor ? `<p>Color: ${o.deviceColor}</p>` : ''}
          <p>Lock: ${o.lockType === 'none' ? 'No Lock' : o.lockType}</p>
          ${o.lockCode ? `<p>Code: ${o.lockCode}</p>` : ''}
        </div>
      </div>
      <table class="invoice-table">
        <thead><tr><th>#</th><th>Repair Work / Problem</th><th>Technician</th><th style="text-align:right">Amount</th></tr></thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>${problems}${o.repairNote ? `<br><small style="color:#999">${o.repairNote}</small>` : ''}</td>
            <td>${o.techName || '—'}</td>
            <td style="text-align:right;font-weight:600">₹${finalAmt.toLocaleString('en-IN')}</td>
          </tr>
        </tbody>
      </table>
      <div class="invoice-totals">
        <div class="invoice-total-row"><div class="invoice-total-label">Subtotal</div><div class="invoice-total-value">₹${finalAmt.toLocaleString('en-IN')}</div></div>
        <div class="invoice-total-row"><div class="invoice-total-label">Advance Paid</div><div class="invoice-total-value">— ₹${advance.toLocaleString('en-IN')}</div></div>
        <div class="invoice-total-row invoice-grand-row"><div class="invoice-total-label">Balance Due</div><div class="invoice-total-value">₹${balance.toLocaleString('en-IN')}</div></div>
      </div>
      <div style="background:#f8fafc;border-radius:8px;padding:12px 16px;margin-bottom:20px;font-size:13px">
        <strong>Payment:</strong> ${o.paymentStatus} &nbsp;&nbsp;
        <strong>Status:</strong> ${o.status}
      </div>
      <div class="invoice-footer">
        <p>Thank you for your business! 🙏</p>
        ${s.phone ? `<p>Contact: ${s.phone}</p>` : ''}
      </div>
    </div>`;

  openModal('invoiceModal');
}

// ============ WHATSAPP ============
function sendWhatsApp(id) {
  const o = db.orders.find(x => x.id === id);
  if (!o) return;
  const problems = o.selectedProblems && o.selectedProblems.length > 0
    ? o.selectedProblems.join(', ')
    : (o.problemDesc || 'Repair');
  const msg = encodeURIComponent(
    `🔧 *Repair Update — ${o.id}*\n\n` +
    `Namaste *${o.custName}* ji 🙏\n\n` +
    `📱 Device: ${o.deviceBrand} ${o.deviceModel}\n` +
    `🛠️ Kaam: ${problems}\n` +
    `📋 Status: *${o.status}*\n` +
    `💰 Amount: ₹${o.finalAmt || o.estimateAmt || 0}\n\n` +
    `— ${db.settings.shopName || 'Repair Shop'}`
  );
  window.open(`https://wa.me/91${o.custPhone}?text=${msg}`, '_blank');
}

// ============ INVENTORY ============
function renderInventory() {
  const parts = db.parts;
  const tbody = document.getElementById('inventoryBody');
  if (!tbody) return;

  if (parts.length === 0) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="9">No parts added yet.</td></tr>';
    return;
  }
  tbody.innerHTML = parts.map(p => {
    const isLow = p.stock <= p.minStock;
    return `<tr>
      <td><strong>${p.name}</strong></td>
      <td>${p.category}</td>
      <td>${p.compat || '—'}</td>
      <td style="font-size:18px;font-weight:700;color:${isLow ? 'var(--accent-red)' : 'var(--accent-green)'}">${p.stock}</td>
      <td>${p.minStock}</td>
      <td>₹${p.purchasePrice || 0}</td>
      <td>₹${p.sellPrice || 0}</td>
      <td>${isLow ? '<span class="badge badge-unpaid">⚠️ Low Stock</span>' : '<span class="badge badge-paid">✅ In Stock</span>'}</td>
      <td><div class="action-btns">
        <button class="btn btn-sm btn-outline" onclick="openPartModal('${p.id}')">✏️</button>
        <button class="btn btn-sm btn-danger" onclick="deletePart('${p.id}')">🗑️</button>
      </div></td>
    </tr>`;
  }).join('');
}

function openPartModal(id = null) {
  document.getElementById('partForm').reset();
  document.getElementById('editPartId').value = '';
  document.getElementById('partModalTitle').textContent = 'Add New Part';
  if (id) {
    const p = db.parts.find(x => x.id === id);
    if (p) {
      document.getElementById('editPartId').value = p.id;
      document.getElementById('partModalTitle').textContent = 'Edit Part';
      document.getElementById('partName').value = p.name;
      document.getElementById('partCategory').value = p.category;
      document.getElementById('partCompat').value = p.compat || '';
      document.getElementById('partStock').value = p.stock;
      document.getElementById('partMinStock').value = p.minStock;
      document.getElementById('partPurchase').value = p.purchasePrice || '';
      document.getElementById('partSell').value = p.sellPrice || '';
    }
  }
  openModal('partModal');
}

function handlePartSubmit(e) {
  e.preventDefault();
  const editId = document.getElementById('editPartId').value;
  const data = {
    name: document.getElementById('partName').value.trim(),
    category: document.getElementById('partCategory').value,
    compat: document.getElementById('partCompat').value.trim(),
    stock: parseInt(document.getElementById('partStock').value) || 0,
    minStock: parseInt(document.getElementById('partMinStock').value) || 2,
    purchasePrice: parseFloat(document.getElementById('partPurchase').value) || 0,
    sellPrice: parseFloat(document.getElementById('partSell').value) || 0,
  };
  if (editId) {
    const idx = db.parts.findIndex(p => p.id === editId);
    if (idx !== -1) db.parts[idx] = { ...db.parts[idx], ...data };
    showToast('Part update ho gaya!', 'success');
  } else {
    db.parts.push({ id: 'p' + Date.now(), ...data });
    showToast('Part add ho gaya!', 'success');
  }
  saveDB(); closeModal('partModal'); renderInventory(); renderDashboard();
}

function deletePart(id) {
  if (!confirm('Yeh part delete karna chahte ho?')) return;
  db.parts = db.parts.filter(p => p.id !== id);
  saveDB(); renderInventory();
  showToast('Part delete ho gaya.', 'error');
}

// ============ TECHNICIANS ============
function renderTechnicians() {
  const techs = db.technicians;
  const grid = document.getElementById('techGrid');
  if (!grid) return;
  if (techs.length === 0) { grid.innerHTML = '<div class="empty-state">No technicians added.</div>'; return; }

  grid.innerHTML = techs.map(t => {
    const jobs = db.orders.filter(o => o.techId === t.id).length;
    const done = db.orders.filter(o => o.techId === t.id && (o.status === 'Completed' || o.status === 'Delivered')).length;
    const rev = db.orders.filter(o => o.techId === t.id).reduce((s, o) => s + (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0), 0);
    const sc = t.status === 'Active' ? 'badge-paid' : t.status === 'On Leave' ? 'badge-partial' : 'badge-unpaid';
    return `<div class="tech-card">
      <div class="tech-card-header">
        <div class="tech-avatar">${t.name[0]}</div>
        <div>
          <div class="tech-name">${t.name}</div>
          <div class="tech-spec">${t.spec}</div>
          <div style="font-size:12px;color:var(--text-muted)">${t.phone}</div>
        </div>
        <div style="margin-left:auto"><span class="badge ${sc}">${t.status}</span></div>
      </div>
      <div class="tech-stats">
        <div class="tech-stat"><div class="tech-stat-value">${jobs}</div><div class="tech-stat-label">Total Jobs</div></div>
        <div class="tech-stat"><div class="tech-stat-value" style="color:var(--accent-green)">${done}</div><div class="tech-stat-label">Completed</div></div>
        <div class="tech-stat" style="grid-column:1/-1"><div class="tech-stat-value" style="color:var(--accent-yellow)">₹${rev.toLocaleString('en-IN')}</div><div class="tech-stat-label">Revenue</div></div>
      </div>
      <div class="tech-actions">
        <button class="btn btn-sm btn-outline" onclick="openTechModal('${t.id}')">✏️ Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteTech('${t.id}')">🗑️</button>
      </div>
    </div>`;
  }).join('');
}

function openTechModal(id = null) {
  document.getElementById('techForm').reset();
  document.getElementById('editTechId').value = '';
  document.getElementById('techModalTitle').textContent = 'Add Technician';
  if (id) {
    const t = db.technicians.find(x => x.id === id);
    if (t) {
      document.getElementById('editTechId').value = t.id;
      document.getElementById('techModalTitle').textContent = 'Edit Technician';
      document.getElementById('techName').value = t.name;
      document.getElementById('techPhone').value = t.phone;
      document.getElementById('techSpec').value = t.spec;
      document.getElementById('techStatus').value = t.status;
    }
  }
  openModal('techModal');
}

function handleTechSubmit(e) {
  e.preventDefault();
  const editId = document.getElementById('editTechId').value;
  const data = {
    name: document.getElementById('techName').value.trim(),
    phone: document.getElementById('techPhone').value.trim(),
    spec: document.getElementById('techSpec').value,
    status: document.getElementById('techStatus').value,
  };
  if (editId) {
    const idx = db.technicians.findIndex(t => t.id === editId);
    if (idx !== -1) db.technicians[idx] = { ...db.technicians[idx], ...data };
    showToast('Technician update ho gaya!', 'success');
  } else {
    db.technicians.push({ id: 't' + Date.now(), ...data });
    showToast('Technician add ho gaya!', 'success');
  }
  saveDB(); closeModal('techModal'); renderTechnicians();
}

function deleteTech(id) {
  if (!confirm('Yeh technician remove karna chahte ho?')) return;
  db.technicians = db.technicians.filter(t => t.id !== id);
  saveDB(); renderTechnicians();
  showToast('Technician remove ho gaya.', 'error');
}

// ============ REPORTS ============
function loadReports() {
  const period = document.getElementById('reportPeriod') ? document.getElementById('reportPeriod').value : 'month';
  const now = new Date();
  let orders = [...db.orders];

  if (period === 'week') {
    const start = new Date(now - 7 * 86400000);
    orders = orders.filter(o => new Date(o.date) >= start);
  } else if (period === 'month') {
    orders = orders.filter(o => { const d = new Date(o.date); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); });
  } else if (period === 'year') {
    orders = orders.filter(o => new Date(o.date).getFullYear() === now.getFullYear());
  }

  const total = orders.length;
  const revenue = orders.reduce((s, o) => s + (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0), 0);
  const pending = orders.filter(o => o.status === 'Pending').length;
  const avg = total > 0 ? Math.round(revenue / total) : 0;

  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('rTotalOrders', total);
  set('rRevenue', '₹' + revenue.toLocaleString('en-IN'));
  set('rPending', pending);
  set('rAvgAmount', '₹' + avg.toLocaleString('en-IN'));

  const statuses = ['Pending', 'In Progress', 'Waiting for Parts', 'Completed', 'Delivered'];
  const colors = ['#eab308', '#6366f1', '#f97316', '#22c55e', '#a78bfa'];
  const maxRev = Math.max(...statuses.map(s => orders.filter(o => o.status === s).reduce((sum, o) => sum + (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0), 0)), 1);

  const revChart = document.getElementById('revenueChart');
  if (revChart) revChart.innerHTML = `<div class="bar-chart">${statuses.map((s, i) => {
    const rev = orders.filter(o => o.status === s).reduce((sum, o) => sum + (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0), 0);
    return `<div class="bar-item"><div class="bar-label"><span>${s}</span><span>₹${rev.toLocaleString('en-IN')}</span></div><div class="bar-track"><div class="bar-fill" style="width:${(rev/maxRev*100).toFixed(1)}%;background:${colors[i]}"></div></div></div>`;
  }).join('')}</div>`;

  const techPerf = db.technicians.map(t => ({ ...t, jobs: orders.filter(o => o.techId === t.id).length })).sort((a, b) => b.jobs - a.jobs);
  const tp = document.getElementById('techPerformance');
  if (tp) tp.innerHTML = techPerf.length === 0 ? '<div class="empty-state-sm">No data</div>'
    : techPerf.map(t => `<div class="tech-perf-item"><div class="tech-perf-avatar">${t.name[0]}</div><div class="tech-perf-info"><div class="tech-perf-name">${t.name}</div><div class="tech-perf-jobs">${t.spec}</div></div><div class="tech-perf-count">${t.jobs}</div></div>`).join('');

  const brands = {};
  orders.forEach(o => { brands[o.deviceBrand] = (brands[o.deviceBrand] || 0) + 1; });
  const sortedBrands = Object.entries(brands).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const maxB = Math.max(...sortedBrands.map(b => b[1]), 1);
  const bColors = ['#6366f1', '#22c55e', '#eab308', '#a78bfa', '#f97316', '#06b6d4'];
  const bc = document.getElementById('brandChart');
  if (bc) bc.innerHTML = sortedBrands.length === 0 ? '<div class="empty-state-sm">No data</div>'
    : sortedBrands.map(([brand, count], i) => `<div class="brand-item"><div class="brand-name">${brand}</div><div class="brand-bar-track"><div class="brand-bar-fill" style="width:${count/maxB*100}%;background:${bColors[i%bColors.length]}"></div></div><div class="brand-count">${count}</div></div>`).join('');

  const paid = orders.filter(o => o.paymentStatus === 'Paid').reduce((s, o) => s + (parseFloat(o.finalAmt) || parseFloat(o.estimateAmt) || 0), 0);
  const unpaid = orders.filter(o => o.paymentStatus === 'Unpaid').reduce((s, o) => s + (parseFloat(o.estimateAmt) || 0), 0);
  const partial = orders.filter(o => o.paymentStatus === 'Partial').reduce((s, o) => s + ((parseFloat(o.estimateAmt) || 0) - (parseFloat(o.advanceAmt) || 0)), 0);
  const ps = document.getElementById('paymentSummary');
  if (ps) ps.innerHTML = `
    <div class="payment-item"><span class="payment-label">💰 Collected</span><span class="payment-value" style="color:var(--accent-green)">₹${paid.toLocaleString('en-IN')}</span></div>
    <div class="payment-item"><span class="payment-label">⏳ Partial Due</span><span class="payment-value" style="color:var(--accent-yellow)">₹${partial.toLocaleString('en-IN')}</span></div>
    <div class="payment-item"><span class="payment-label">❌ Uncollected</span><span class="payment-value" style="color:var(--accent-red)">₹${unpaid.toLocaleString('en-IN')}</span></div>
    <div class="payment-item" style="background:rgba(99,102,241,0.1);border:1px solid rgba(99,102,241,0.3)"><span class="payment-label" style="font-weight:700">📊 Total Expected</span><span class="payment-value" style="color:var(--accent-blue)">₹${(paid+unpaid+partial).toLocaleString('en-IN')}</span></div>`;
}

// ============ SETTINGS ============
function loadSettings() {
  const s = db.settings;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v || ''; };
  set('settingShopName', s.shopName);
  set('settingOwnerName', s.ownerName);
  set('settingPhone', s.phone);
  set('settingGST', s.gst);
  set('settingAddress', s.address);
  const sn = document.getElementById('sidebarShopName');
  if (sn) sn.textContent = s.shopName || 'My Shop';
}

function saveSettings() {
  db.settings = {
    shopName: document.getElementById('settingShopName').value.trim(),
    ownerName: document.getElementById('settingOwnerName').value.trim(),
    phone: document.getElementById('settingPhone').value.trim(),
    gst: document.getElementById('settingGST').value.trim(),
    address: document.getElementById('settingAddress').value.trim()
  };
  saveDB();
  const sn = document.getElementById('sidebarShopName');
  if (sn) sn.textContent = db.settings.shopName || 'My Shop';
  showToast('Settings save ho gayi!', 'success');
}


// ============ MODAL HELPERS ============
function openModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.add('open'); document.body.style.overflow = 'hidden'; }
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.remove('open'); document.body.style.overflow = ''; }
}

// ============ UTILS ============
function formatDate(dateStr) {
  if (!dateStr) return '—';
  try {
    const d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch(e) { return dateStr; }
}

