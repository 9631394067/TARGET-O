# RepairPro - Permanent Local Project Data

## How to run
1. Install Node.js LTS.
2. Double-click `start.bat`.
3. Use RepairPro in the browser opened by the script.
4. Do NOT open `index.html` by double-clicking it.

## Where data is saved
Every save from the app is written by `server.js` into BOTH:
- `data/repairpro-data.js` — human-readable project data file; records are literally stored in this JS data file.
- `data/repairpro-data.json` — machine-readable database copy.
A previous JSON copy is kept at `data/repairpro-data.backup.json`.

The app uses the server files as the primary source. Browser LocalStorage/IndexedDB remain recovery copies.

## Data flow
New Order -> Save -> server.js -> data/repairpro-data.js + data/repairpro-data.json.

Closing the app/browser, restarting Windows, or shutting down the PC does not remove these files. They remain in the project folder unless the files/folder are deliberately deleted or the storage device fails.

## Important
This is permanent LOCAL storage, not cloud storage. Keep a backup of the whole `data` folder. Do not edit the data files manually while RepairPro is running.

## Phone number
Customer phone input accepts exactly 10 digits; more than 10 cannot be typed and fewer than 10 prevents form submission.


## LIVE DATA LOCATION
The `data` folder is the permanent project data folder. After you save an order,
refresh `data/repairpro-data.js` or `data/repairpro-data.json` in VS Code to see it.
The browser is only used as a recovery copy; the project data files are written by
the local Node.js server.
