const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = Number(process.env.PORT || 8080);
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const JSON_FILE = path.join(DATA_DIR, 'repairpro-data.json');
const JS_FILE = path.join(DATA_DIR, 'repairpro-data.js');
const BACKUP_FILE = path.join(DATA_DIR, 'repairpro-data.backup.json');

const SEED = {"db": {"technicians": [{"id": "t1", "name": "Rahul Sharma", "phone": "9876543210", "spec": "Samsung Specialist", "status": "Active"}, {"id": "t2", "name": "Amit Kumar", "phone": "9876543211", "spec": "iPhone Specialist", "status": "Active"}, {"id": "t3", "name": "Suresh Verma", "phone": "9876543212", "spec": "Board Level Repair", "status": "Active"}], "parts": [{"id": "p1", "name": "Samsung S21 Display", "category": "Display / Screen", "compat": "Samsung S21", "stock": 3, "minStock": 2, "purchasePrice": 2500, "sellPrice": 3500}, {"id": "p2", "name": "iPhone 13 Battery", "category": "Battery", "compat": "iPhone 13", "stock": 5, "minStock": 3, "purchasePrice": 1200, "sellPrice": 1800}, {"id": "p3", "name": "Universal Charging Port", "category": "Charging Port", "compat": "Universal", "stock": 1, "minStock": 3, "purchasePrice": 150, "sellPrice": 350}], "orders": [{"id": "RP-1000", "date": "2026-07-24", "phoneReceivedDate": "2026-07-24", "phoneDeliveredDate": "", "custName": "Ramesh Gupta", "custPhone": "9811223344", "custEmail": "ramesh@gmail.com", "custAddress": "Delhi", "customerId": "", "invoiceNo": "INV-1000", "custPhoto": null, "deviceBrand": "Samsung", "deviceModel": "Galaxy S21", "imei": "358943085670234", "deviceColor": "Phantom Black", "conditions": ["Screen Crack"], "lockType": "pin", "lockCode": "1234", "lockPatternNote": "", "accessories": {"sim": "yes", "cover": "no", "charger": "yes", "earphone": "no"}, "selectedProblems": ["Display Replace"], "repairNote": "Handle with care", "techId": "t1", "techName": "Rahul Sharma", "priority": "High", "status": "Completed", "estimateAmt": 3500, "advanceAmt": 1000, "finalAmt": 3500, "paymentStatus": "Paid", "notes": "Done successfully", "photo": null, "createdAt": "2026-07-24"}, {"id": "RP-1001", "date": "2026-07-26", "phoneReceivedDate": "2026-07-26", "phoneDeliveredDate": "2026-07-28", "custName": "Priya Singh", "custPhone": "9922334455", "custEmail": "", "custAddress": "Noida", "customerId": "", "invoiceNo": "INV-1001", "custPhoto": null, "deviceBrand": "iPhone / Apple", "deviceModel": "iPhone 13", "imei": "354987654321001", "deviceColor": "Blue", "conditions": ["Normal Condition"], "lockType": "fingerprint", "lockCode": "", "lockPatternNote": "", "accessories": {"sim": "yes", "cover": "yes", "charger": "no", "earphone": "no"}, "selectedProblems": ["Battery Replace"], "repairNote": "", "techId": "t2", "techName": "Amit Kumar", "priority": "Normal", "status": "Delivered", "estimateAmt": 1800, "advanceAmt": 500, "finalAmt": 1800, "paymentStatus": "Paid", "notes": "", "photo": null, "createdAt": "2026-07-26"}, {"id": "RP-1002", "date": "2026-07-27", "phoneReceivedDate": "2026-07-27", "phoneDeliveredDate": "", "custName": "Vikas Yadav", "custPhone": "9733445566", "custEmail": "", "custAddress": "Gurgaon", "customerId": "CUST-003", "invoiceNo": "INV-1002", "custPhoto": null, "deviceBrand": "Xiaomi / Redmi", "deviceModel": "Redmi Note 12", "imei": "", "deviceColor": "Gray", "conditions": ["Water Damage", "Body Damage"], "lockType": "pattern", "lockCode": "", "lockPatternNote": "L-shape", "accessories": {"sim": "no", "cover": "no", "charger": "no", "earphone": "no"}, "selectedProblems": ["Water Damage", "Charging Board Replace"], "repairNote": "Check motherboard carefully", "techId": "t3", "techName": "Suresh Verma", "priority": "Urgent", "status": "In Progress", "estimateAmt": 2000, "advanceAmt": 800, "finalAmt": 0, "paymentStatus": "Partial", "notes": "Waiting for board", "photo": null, "createdAt": "2026-07-27"}, {"id": "RP-1003", "date": "2026-07-28", "phoneReceivedDate": "2026-07-28", "phoneDeliveredDate": "", "custName": "Anita Rao", "custPhone": "9644556677", "custEmail": "anita@gmail.com", "custAddress": "Faridabad", "customerId": "", "invoiceNo": "INV-1003", "custPhoto": null, "deviceBrand": "Realme", "deviceModel": "Realme 9 Pro", "imei": "123456789012345", "deviceColor": "Sunrise Blue", "conditions": ["Screen Crack"], "lockType": "pin", "lockCode": "0000", "lockPatternNote": "", "accessories": {"sim": "yes", "cover": "yes", "charger": "yes", "earphone": "no"}, "selectedProblems": ["Display Replace"], "repairNote": "", "techId": "t1", "techName": "Rahul Sharma", "priority": "Normal", "status": "Pending", "estimateAmt": 1200, "advanceAmt": 0, "finalAmt": 0, "paymentStatus": "Unpaid", "notes": "", "photo": null, "createdAt": "2026-07-28"}, {"id": "RP-1004", "date": "2026-07-29", "phoneReceivedDate": "2026-07-29", "phoneDeliveredDate": "", "custName": "Mohit Sharma", "custPhone": "9555667788", "custEmail": "", "custAddress": "Ghaziabad", "customerId": "", "invoiceNo": "INV-1004", "custPhoto": null, "deviceBrand": "OnePlus", "deviceModel": "OnePlus 11", "imei": "", "deviceColor": "Titan Black", "conditions": [], "lockType": "none", "lockCode": "", "lockPatternNote": "", "accessories": {"sim": "no", "cover": "no", "charger": "yes", "earphone": "no"}, "selectedProblems": ["Charging Pin Replace", "Network Problem"], "repairNote": "USB-C port damaged", "techId": "t2", "techName": "Amit Kumar", "priority": "High", "status": "Waiting for Parts", "estimateAmt": 800, "advanceAmt": 300, "finalAmt": 0, "paymentStatus": "Partial", "notes": "Waiting for USB-C port", "photo": null, "createdAt": "2026-07-29"}], "settings": {"shopName": "My Repair Shop", "ownerName": "Admin", "phone": "", "gst": "", "address": ""}}, "orderCounter": 1005};

fs.mkdirSync(DATA_DIR, { recursive: true });

function validPayload(p) {
  return p && p.db && Array.isArray(p.db.orders) &&
    Array.isArray(p.db.parts) && Array.isArray(p.db.technicians) &&
    p.db.settings && typeof p.db.settings === 'object';
}

function normalizePayload(p) {
  return {
    db: {
      orders: Array.isArray(p?.db?.orders) ? p.db.orders : [],
      parts: Array.isArray(p?.db?.parts) ? p.db.parts : [],
      technicians: Array.isArray(p?.db?.technicians) ? p.db.technicians : [],
      settings: p?.db?.settings || { shopName:'My Repair Shop', ownerName:'Admin', phone:'', gst:'', address:'' }
    },
    orderCounter: Number.isFinite(Number(p?.orderCounter)) ? Number(p.orderCounter) : 1000
  };
}

function readJsonFile() {
  try {
    if (!fs.existsSync(JSON_FILE)) return null;
    const value = JSON.parse(fs.readFileSync(JSON_FILE, 'utf8'));
    return validPayload(value) ? normalizePayload(value) : null;
  } catch { return null; }
}

function readJsFile() {
  try {
    if (!fs.existsSync(JS_FILE)) return null;
    const text = fs.readFileSync(JS_FILE, 'utf8');
    const marker = 'window.REPAIRPRO_DATA = ';
    const start = text.indexOf(marker);
    if (start < 0) return null;
    const jsonStart = start + marker.length;
    const end = text.indexOf(';\n', jsonStart);
    if (end < 0) return null;
    const value = JSON.parse(text.slice(jsonStart, end));
    return validPayload(value) ? normalizePayload(value) : null;
  } catch { return null; }
}

function writeAtomic(file, text) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, text, 'utf8');
  fs.renameSync(tmp, file);
}

function writeData(payload) {
  const normalized = normalizePayload(payload);
  const stamp = new Date().toISOString();
  const stored = { ...normalized, savedAt: stamp };

  // Keep the previous JSON as a recovery copy before replacing the main file.
  if (fs.existsSync(JSON_FILE)) {
    try { fs.copyFileSync(JSON_FILE, BACKUP_FILE); } catch {}
  }

  // JSON is the machine-readable database copy.
  writeAtomic(JSON_FILE, JSON.stringify(stored, null, 2));

  // JS is the human-readable/project copy requested by the owner.
  const jsText =
`// RepairPro permanent project data.
// This file is automatically updated whenever the app saves.
// Do not edit while RepairPro is running; use the app instead.
window.REPAIRPRO_DATA = ${JSON.stringify(stored, null, 2)};
`;
  writeAtomic(JS_FILE, jsText);

  return stored;
}

let data = readJsFile() || readJsonFile();
if (!data || data.db.orders.length === 0 && data.db.parts.length === 0 && data.db.technicians.length === 0) {
  data = { db: SEED.db, orderCounter: SEED.orderCounter };
  writeData(data);
}

let writeQueue = Promise.resolve();

function queuedWrite(payload) {
  writeQueue = writeQueue.then(() => writeData(payload));
  return writeQueue;
}

function send(res, status, body, type='application/json') {
  res.writeHead(status, {
    'Content-Type': type,
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}

function serveStatic(req, res) {
  let urlPath = decodeURIComponent(req.url.split('?')[0]);
  if (urlPath === '/') urlPath = '/index.html';
  const file = path.normalize(path.join(ROOT, urlPath));
  if (!file.startsWith(ROOT)) return send(res, 403, 'Forbidden', 'text/plain');
  fs.readFile(file, (err, content) => {
    if (err) return send(res, 404, 'Not found', 'text/plain');
    const ext = path.extname(file).toLowerCase();
    const types = {
      '.html':'text/html; charset=utf-8',
      '.js':'application/javascript; charset=utf-8',
      '.css':'text/css; charset=utf-8',
      '.json':'application/json; charset=utf-8',
      '.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'
    };
    send(res, 200, content, types[ext] || 'application/octet-stream');
  });
}

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];

  if (req.method === 'GET' && url === '/api/data') {
    const current = readJsFile() || readJsonFile() || data;
    data = current;
    return send(res, 200, current);
  }

  if (req.method === 'PUT' && url === '/api/data') {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 25 * 1024 * 1024) req.destroy();
    });
    req.on('end', async () => {
      try {
        const payload = JSON.parse(raw);
        if (!validPayload(payload)) throw new Error('Invalid RepairPro database payload');
        const saved = await queuedWrite(payload);
        data = saved;
        send(res, 200, { ok:true, savedAt:saved.savedAt, files:['data/repairpro-data.js','data/repairpro-data.json'] });
      } catch (e) {
        send(res, 400, { ok:false, error:e.message });
      }
    });
    return;
  }

  serveStatic(req, res);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log('RepairPro is running at http://127.0.0.1:' + PORT);
  console.log('Permanent data: ' + JSON_FILE);
  console.log('Project data:   ' + JS_FILE);
  console.log('Backup:         ' + BACKUP_FILE);
  console.log('');
});
