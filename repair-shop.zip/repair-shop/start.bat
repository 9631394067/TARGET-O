@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js LTS first, then run this file again.
  pause
  exit /b 1
)
start "RepairPro Server" cmd /k node server.js
ping 127.0.0.1 -n 3 >nul
start "RepairPro" http://127.0.0.1:8080
