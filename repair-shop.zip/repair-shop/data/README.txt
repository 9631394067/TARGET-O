RepairPro - LIVE DATA FOLDER

This folder contains the permanent local project data.

1. repairpro-data.js
   - Human-readable JavaScript copy of the CURRENT RepairPro data.
   - This file is automatically rewritten every time you save an order,
     inventory item, technician, or settings change.

2. repairpro-data.json
   - Machine-readable copy of the same CURRENT data.
   - This is also rewritten automatically on every successful save.

3. repairpro-data.backup.json
   - Previous JSON copy kept as a recovery backup before the next save.

HOW TO SEE NEW DATA:
- Start the application with start.bat.
- Add/save an order.
- Return to this data folder.
- Refresh/reopen repairpro-data.js or repairpro-data.json in VS Code.
- Your new order will be visible there.

IMPORTANT:
- Do not open index.html directly. Use start.bat.
- Do not manually edit these data files while the app is running.
- Closing the browser, stopping the app, restarting, or shutting down Windows
  does not remove these files.
- Keep a copy of the entire data folder for backup.
\n\nBackup restore update: Settings > Restore Backup now accepts both RepairPro downloaded backups and repairpro-data.json / repairpro-data.backup.json files from this data folder.\n