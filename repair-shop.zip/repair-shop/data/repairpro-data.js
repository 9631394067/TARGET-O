// RepairPro permanent project data.
// Automatically updated when app saves.
window.REPAIRPRO_DATA = {
  "db": {
    "technicians": [
      {
        "id": "t1",
        "name": "Rahul Sharma",
        "phone": "9876543210",
        "spec": "Samsung Specialist",
        "status": "Active"
      },
      {
        "id": "t2",
        "name": "Amit Kumar",
        "phone": "9876543211",
        "spec": "iPhone Specialist",
        "status": "Active"
      },
      {
        "id": "t3",
        "name": "Suresh Verma",
        "phone": "9876543212",
        "spec": "Board Level Repair",
        "status": "Active"
      }
    ],
    "parts": [
      {
        "id": "p1",
        "name": "Samsung S21 Display",
        "category": "Display / Screen",
        "compat": "Samsung S21",
        "stock": 3,
        "minStock": 2,
        "purchasePrice": 2500,
        "sellPrice": 3500
      },
      {
        "id": "p2",
        "name": "iPhone 13 Battery",
        "category": "Battery",
        "compat": "iPhone 13",
        "stock": 5,
        "minStock": 3,
        "purchasePrice": 1200,
        "sellPrice": 1800
      },
      {
        "id": "p3",
        "name": "Universal Charging Port",
        "category": "Charging Port",
        "compat": "Universal",
        "stock": 1,
        "minStock": 3,
        "purchasePrice": 150,
        "sellPrice": 350
      }
    ],
    "orders": [
      {
        "id": "RP-1000",
        "date": "2026-07-24",
        "phoneReceivedDate": "2026-07-24",
        "phoneDeliveredDate": "",
        "custName": "Ramesh Gupta",
        "custPhone": "9811223344",
        "custEmail": "ramesh@gmail.com",
        "custAddress": "Delhi",
        "customerId": "",
        "invoiceNo": "INV-1000",
        "custPhoto": null,
        "deviceBrand": "Samsung",
        "deviceModel": "Galaxy S21",
        "imei": "358943085670234",
        "deviceColor": "Phantom Black",
        "conditions": [
          "Screen Crack"
        ],
        "lockType": "pin",
        "lockCode": "1234",
        "lockPatternNote": "",
        "accessories": {
          "sim": "yes",
          "cover": "no",
          "charger": "yes",
          "earphone": "no"
        },
        "selectedProblems": [
          "Display Replace"
        ],
        "repairNote": "Handle with care",
        "techId": "t1",
        "techName": "Rahul Sharma",
        "priority": "High",
        "status": "Completed",
        "estimateAmt": 3500,
        "advanceAmt": 1000,
        "finalAmt": 3500,
        "paymentStatus": "Paid",
        "notes": "Done successfully",
        "photo": null,
        "createdAt": "2026-07-24"
      },
      {
        "id": "RP-1001",
        "date": "2026-07-26",
        "phoneReceivedDate": "2026-07-26",
        "phoneDeliveredDate": "2026-07-28",
        "custName": "Priya Singh",
        "custPhone": "9922334455",
        "custEmail": "",
        "custAddress": "Noida",
        "customerId": "",
        "invoiceNo": "INV-1001",
        "custPhoto": null,
        "deviceBrand": "iPhone / Apple",
        "deviceModel": "iPhone 13",
        "imei": "354987654321001",
        "deviceColor": "Blue",
        "conditions": [
          "Normal Condition"
        ],
        "lockType": "fingerprint",
        "lockCode": "",
        "lockPatternNote": "",
        "accessories": {
          "sim": "yes",
          "cover": "yes",
          "charger": "no",
          "earphone": "no"
        },
        "selectedProblems": [
          "Battery Replace"
        ],
        "repairNote": "",
        "techId": "t2",
        "techName": "Amit Kumar",
        "priority": "Normal",
        "status": "Delivered",
        "estimateAmt": 1800,
        "advanceAmt": 500,
        "finalAmt": 1800,
        "paymentStatus": "Paid",
        "notes": "",
        "photo": null,
        "createdAt": "2026-07-26"
      },
      {
        "id": "RP-1002",
        "date": "2026-07-27",
        "phoneReceivedDate": "2026-07-27",
        "phoneDeliveredDate": "",
        "custName": "Vikas Yadav",
        "custPhone": "9733445566",
        "custEmail": "",
        "custAddress": "Gurgaon",
        "customerId": "CUST-003",
        "invoiceNo": "INV-1002",
        "custPhoto": null,
        "deviceBrand": "Xiaomi / Redmi",
        "deviceModel": "Redmi Note 12",
        "imei": "",
        "deviceColor": "Gray",
        "conditions": [
          "Water Damage",
          "Body Damage"
        ],
        "lockType": "pattern",
        "lockCode": "",
        "lockPatternNote": "L-shape",
        "accessories": {
          "sim": "no",
          "cover": "no",
          "charger": "no",
          "earphone": "no"
        },
        "selectedProblems": [
          "Water Damage",
          "Charging Board Replace"
        ],
        "repairNote": "Check motherboard carefully",
        "techId": "t3",
        "techName": "Suresh Verma",
        "priority": "Urgent",
        "status": "In Progress",
        "estimateAmt": 2000,
        "advanceAmt": 800,
        "finalAmt": 0,
        "paymentStatus": "Partial",
        "notes": "Waiting for board",
        "photo": null,
        "createdAt": "2026-07-27"
      },
      {
        "id": "RP-1003",
        "date": "2026-07-28",
        "phoneReceivedDate": "2026-07-28",
        "phoneDeliveredDate": "",
        "custName": "Anita Rao",
        "custPhone": "9644556677",
        "custEmail": "anita@gmail.com",
        "custAddress": "Faridabad",
        "customerId": "",
        "invoiceNo": "INV-1003",
        "custPhoto": null,
        "deviceBrand": "Realme",
        "deviceModel": "Realme 9 Pro",
        "imei": "123456789012345",
        "deviceColor": "Sunrise Blue",
        "conditions": [
          "Screen Crack"
        ],
        "lockType": "pin",
        "lockCode": "0000",
        "lockPatternNote": "",
        "accessories": {
          "sim": "yes",
          "cover": "yes",
          "charger": "yes",
          "earphone": "no"
        },
        "selectedProblems": [
          "Display Replace"
        ],
        "repairNote": "",
        "techId": "t1",
        "techName": "Rahul Sharma",
        "priority": "Normal",
        "status": "Pending",
        "estimateAmt": 1200,
        "advanceAmt": 0,
        "finalAmt": 0,
        "paymentStatus": "Unpaid",
        "notes": "",
        "photo": null,
        "createdAt": "2026-07-28"
      },
      {
        "id": "RP-1004",
        "date": "2026-07-29",
        "phoneReceivedDate": "2026-07-29",
        "phoneDeliveredDate": "",
        "custName": "Mohit Sharma",
        "custPhone": "9555667788",
        "custEmail": "",
        "custAddress": "Ghaziabad",
        "customerId": "",
        "invoiceNo": "INV-1004",
        "custPhoto": null,
        "deviceBrand": "OnePlus",
        "deviceModel": "OnePlus 11",
        "imei": "",
        "deviceColor": "Titan Black",
        "conditions": [],
        "lockType": "none",
        "lockCode": "",
        "lockPatternNote": "",
        "accessories": {
          "sim": "no",
          "cover": "no",
          "charger": "yes",
          "earphone": "no"
        },
        "selectedProblems": [
          "Charging Pin Replace",
          "Network Problem"
        ],
        "repairNote": "USB-C port damaged",
        "techId": "t2",
        "techName": "Amit Kumar",
        "priority": "High",
        "status": "Waiting for Parts",
        "estimateAmt": 800,
        "advanceAmt": 300,
        "finalAmt": 0,
        "paymentStatus": "Partial",
        "notes": "Waiting for USB-C port",
        "photo": null,
        "createdAt": "2026-07-29"
      }
    ],
    "settings": {
      "shopName": "My Repair Shop",
      "ownerName": "Admin",
      "phone": "",
      "gst": "",
      "address": ""
    }
  },
  "orderCounter": 1005,
  "savedAt": "initial"
};
